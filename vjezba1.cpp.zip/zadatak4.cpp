#include <iostream>
using namespace std;


int& at(int niz[], int i) {
    return niz[i];
}

int main() {
    int niz[5] = {1, 2, 3, 4, 5};
    int i = 2;

    cout << "Prije: ";
    for (int j = 0; j < 5; j++)
        cout << niz[j] << " ";
    cout << endl;

    at(niz, i)++;

    cout << "Poslije: ";
    for (int j = 0; j < 5; j++)
        cout << niz[j] << " ";
    cout << endl;

    return 0;
}

