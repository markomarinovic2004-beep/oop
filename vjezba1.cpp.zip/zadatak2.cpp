#include<iostream>
using namespace std;

int limit( int value, int low = 0, int high = 10){
    if(value<low) return low;
    if(value<high) return high;
    return value;

}

double limit( double value, double low= 0.0, double high = 10.0){

    if(value<low) return low;
    if(value<high) return high;
    return value;
}

int main(){
  cout << limit(5) << endl;
  cout << limit(-3) << endl;
  cout << limit(2.5) << endl;
  cout << limit(12) << endl;
  return 0;

}
